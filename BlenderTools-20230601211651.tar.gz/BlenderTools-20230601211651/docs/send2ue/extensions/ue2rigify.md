# UE to Rigify

A small extension that can sync up your NLA tracks before export.

## Properties
### Sync control rig tracks to source rig
If enabled and using the UE to Rigify addon in control mode, the NLA tracks of the control rig will be
synced to the source rig before they are exported.

## UI
The settings can be found under the `Export` tab
