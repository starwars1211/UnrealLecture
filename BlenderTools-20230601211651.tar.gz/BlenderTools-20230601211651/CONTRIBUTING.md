# Contributing

Directions on how to contribute can be found [here](https://epicgames.github.io/BlenderTools/contributing/development.html).